#!/usr/bin/env python3
"""UBND xã Trà My — hai danh sách dùng chung, không cần đăng nhập, PostgreSQL online.

Không triển khai với SQLite trên nền tảng có filesystem tạm thời.
"""
import argparse
import getpass
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import sqlite3
import sys
import time
import unicodedata
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
DB_URL = os.environ.get('DATABASE_URL', '').strip()
PRODUCTION = os.environ.get('APP_ENV', 'development').lower() == 'production'
if PRODUCTION and not DB_URL.startswith(('postgresql://', 'postgres://')):
    raise RuntimeError('APP_ENV=production yêu cầu DATABASE_URL trỏ PostgreSQL; không dùng SQLite khi chạy online.')
SQLITE_PATH = Path(os.environ.get('SQLITE_PATH', str(ROOT / 'tramy_local.sqlite3')))
# Không đăng nhập: dữ liệu chỉ được phép công bố sau khi cơ quan phê duyệt.
# Ở môi trường production: mặc định CHỈ XEM, muốn sửa phải chủ động bật.
if PRODUCTION and os.environ.get('TRAMY_PUBLIC_ACCESS_APPROVED', '').upper() != 'YES':
    raise RuntimeError('Chưa phê duyệt công bố danh sách công vụ: đặt TRAMY_PUBLIC_ACCESS_APPROVED=YES sau khi được phép.')
ANONYMOUS_WRITE = os.environ.get('TRAMY_ANONYMOUS_WRITE', 'no' if PRODUCTION else 'yes').lower() in ('yes','true','1')
if PRODUCTION and ANONYMOUS_WRITE and os.environ.get('TRAMY_ANONYMOUS_WRITE_APPROVED', '').upper() != 'YES':
    raise RuntimeError('Phải xác nhận rủi ro ghi dữ liệu công khai: TRAMY_ANONYMOUS_WRITE_APPROVED=YES')
MAX_EDIT_PER_MINUTE = 45
MAX_BYTES = 320_000
DEPARTMENTS = [
    'Phòng Văn hóa - Xã hội', 'Phòng Kinh tế',
    'Trung tâm Cung ứng dịch vụ sự nghiệp công',
    'Văn phòng HĐND và UBND', 'Ban CHQS xã', 'Công an xã',
    'Đoàn Thanh niên', 'Hội Liên hiệp Phụ nữ', 'Hội Nông dân',
    'Hội Cựu chiến binh', 'Trạm Y tế',
]

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def ascii_norm(v):
    s = unicodedata.normalize('NFD', str(v or '').casefold()).replace('đ', 'd')
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn')


def normalize_dept(value):
    v = ascii_norm(value)
    if 'van hoa' in v and 'xa hoi' in v:
        return DEPARTMENTS[0]
    if 'kinh te' in v:
        return DEPARTMENTS[1]
    if 'cung ung' in v:
        return DEPARTMENTS[2]
    if 'van phong' in v or 'vp hdnd' in v or 'hdnd&ubnd' in v:
        return DEPARTMENTS[3]
    if 'quan luc' in v or 'chqs' in v or 'quan su' in v:
        return DEPARTMENTS[4]
    if 'cong an' in v:
        return DEPARTMENTS[5]
    if 'doan thanh nien' in v:
        return DEPARTMENTS[6]
    if 'hoi ccb' in v or 'cuu chien binh' in v:
        return DEPARTMENTS[9]
    if 'hoi nong dan' in v:
        return DEPARTMENTS[8]
    if 'phu nu' in v or 'hlhpn' in v:
        return DEPARTMENTS[7]
    if 'tram y te' in v:
        return DEPARTMENTS[10]
    return str(value or '').strip()


class Database:
    """DB-API adapter; '?'-parameters work on SQLite and psycopg 3."""
    def __init__(self):
        self.pg = DB_URL.startswith(('postgresql://', 'postgres://'))
        if self.pg:
            import psycopg
            from psycopg.rows import dict_row
            self.conn = psycopg.connect(DB_URL, row_factory=dict_row, connect_timeout=15)
        else:
            self.conn = sqlite3.connect(str(SQLITE_PATH), timeout=20)
            self.conn.row_factory = sqlite3.Row
            self.conn.execute('PRAGMA foreign_keys=ON')
            self.conn.execute('PRAGMA busy_timeout=20000')
    def execute(self, sql, params=()):
        if self.pg:
            # All SQL statements in this application are constant (never interpolate user text).
            return self.conn.execute(sql.replace('?', '%s'), tuple(params))
        return self.conn.execute(sql, tuple(params))
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self.conn.commit()
            else:
                self.conn.rollback()
        finally:
            self.conn.close()


def connect():
    return Database()


def setup():
    user_id = 'BIGSERIAL PRIMARY KEY' if DB_URL.startswith(('postgresql://','postgres://')) else 'INTEGER PRIMARY KEY AUTOINCREMENT'
    with connect() as db:
        stmts = [
            f'''CREATE TABLE IF NOT EXISTS users (
                id {user_id}, username TEXT NOT NULL UNIQUE,
                display_name TEXT NOT NULL, department TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin','staff')),
                password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL)''',
            '''CREATE TABLE IF NOT EXISTS sessions (
                sid_hash TEXT PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id),
                csrf TEXT NOT NULL, expires BIGINT NOT NULL)''',
            '''CREATE TABLE IF NOT EXISTS records (
                dataset TEXT NOT NULL CHECK(dataset IN ('open','shared')),
                id TEXT NOT NULL, department TEXT NOT NULL,
                content TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
                updated_by BIGINT REFERENCES users(id), updated_at TEXT NOT NULL,
                PRIMARY KEY (dataset, id))''',
            f'''CREATE TABLE IF NOT EXISTS history (
                id {user_id}, user_id BIGINT NOT NULL REFERENCES users(id),
                action TEXT NOT NULL, dataset TEXT NOT NULL, record_id TEXT NOT NULL,
                old_content TEXT, new_content TEXT NOT NULL, changed_at TEXT NOT NULL)''',
            '''CREATE TABLE IF NOT EXISTS login_limits (
                key_hash TEXT PRIMARY KEY, hits INTEGER NOT NULL, window_start BIGINT NOT NULL)''',
            'CREATE INDEX IF NOT EXISTS ix_records_dept ON records(department)',
            'CREATE INDEX IF NOT EXISTS ix_history_changed ON history(changed_at)',
            'CREATE INDEX IF NOT EXISTS ix_sessions_expiry ON sessions(expires)',
        ]
        for s in stmts:
            db.execute(s)
        if db.execute('SELECT COUNT(*) AS n FROM records').fetchone()['n'] == 0:
            seed = json.loads((ROOT / 'seed.json').read_text(encoding='utf-8'))
            for dataset in ('open','shared'):
                for r in seed[dataset]:
                    dept = normalize_dept(r['unit'] if dataset == 'open' else r['position'])
                    db.execute('''INSERT INTO records(dataset,id,department,content,updated_at)
                        VALUES(?,?,?,?,?)''', (dataset, r['id'], dept,
                            json.dumps(r, ensure_ascii=False), utcnow()))
            logging.info('Đã khởi tạo 52 danh mục dữ liệu mở và 43 dòng dữ liệu dùng chung.')
        # Technical audit user. HTTP login endpoints are disabled.
        if not db.execute("SELECT 1 FROM users WHERE username='tramy_khong_dang_nhap'").fetchone():
            db.execute("INSERT INTO users(username,display_name,department,role,password_hash,created_at) VALUES(?,?,?,?,?,?)", (
                'tramy_khong_dang_nhap','Người cập nhật (không xác thực)','',
                'admin','disabled-'+secrets.token_hex(24),utcnow()))
        db.execute("CREATE TABLE IF NOT EXISTS anonymous_limits (key_hash TEXT PRIMARY KEY, hits INTEGER NOT NULL, window_start BIGINT NOT NULL)")


def validate_username(name):
    if not re.fullmatch(r'[a-z0-9_.-]{3,50}', name):
        raise ValueError('Tên đăng nhập: 3-50 ký tự chữ thường, số, dấu chấm, gạch dưới hoặc gạch ngang.')


def validate_password(p):
    if not isinstance(p,str) or len(p)<12 or len(p)>200 or len(set(p))<6:
        raise ValueError('Mật khẩu phải từ 12 đến 200 ký tự, đủ đa dạng.')


def password_hash(p):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', p.encode(), salt, 600_000)
    return 'pbkdf2_sha256$600000$' + salt.hex() + '$' + digest.hex()


def password_matches(p, stored):
    try:
        label, iters, salt, digest = stored.split('$')
        if label != 'pbkdf2_sha256':
            return False
        actual = hashlib.pbkdf2_hmac('sha256', p.encode(), bytes.fromhex(salt), int(iters))
        return hmac.compare_digest(actual, bytes.fromhex(digest))
    except (TypeError,ValueError,OverflowError):
        return False


def validate_record(dataset, record):
    if dataset not in ('open','shared') or not isinstance(record,dict):
        raise ValueError('Dữ liệu gửi lên không hợp lệ.')
    keys = ('id','code','name','field','unit','frequency','sheet','assignee','email','uploaded','note') if dataset=='open' else ('id','stt','name','assignee','position','email','entry_status','note')
    obj={}
    for k in keys:
        if k=='stt':
            try:
                obj[k]=int(record.get(k))
                if not 1<=obj[k]<=5000: raise ValueError('STT ngoài phạm vi.')
            except (ValueError,TypeError):
                raise ValueError('STT phải là số từ 1 đến 5000.')
            continue
        val=record.get(k,'')
        limit = 2000 if k=='note' else 500 if k=='name' else 300
        if not isinstance(val,str) or len(val)>limit:
            raise ValueError('Trường dữ liệu '+k+' không hợp lệ.')
        obj[k]=val.strip()
    if not obj['id'] or len(obj['id'])>80 or not obj['name']:
        raise ValueError('Thiếu mã dòng hoặc tên danh mục.')
    if dataset=='open' and (not obj['code'] or obj['uploaded'] not in ('', 'Có', 'Chưa')):
        raise ValueError('Mã hoặc tình trạng dữ liệu mở không hợp lệ.')
    if dataset=='shared' and obj['entry_status'] not in ('','Đã nhập liệu','Chưa nhập liệu'):
        raise ValueError('Tình trạng nhập liệu dùng chung không hợp lệ.')
    if obj['email'] and not re.fullmatch(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}',obj['email']):
        raise ValueError('Địa chỉ email không hợp lệ.')
    return obj


def rowdict(row):
    return dict(row) if row is not None else None


class AppHandler(BaseHTTPRequestHandler):
    server_version = 'TraMyDuLieu/4.0'
    sys_version = ''
    def log_message(self, fmt, *args):
        logging.info('%s - %s', self.client_address[0], fmt % args)
    def send_bytes(self, code, content, content_type='application/json; charset=utf-8', cookie=None, extra=None):
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control','no-store, private')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
        if PRODUCTION: self.send_header('Strict-Transport-Security','max-age=31536000; includeSubDomains')
        if cookie: self.send_header('Set-Cookie',cookie)
        if extra:
            for k,v in extra.items(): self.send_header(k,v)
        self.end_headers()
        self.wfile.write(content)
    def json(self, obj, code=200, cookie=None):
        self.send_bytes(code, json.dumps(obj,ensure_ascii=False).encode('utf-8'), cookie=cookie)
    def fail(self, message, code):
        self.json({'error':str(message)},code)
    def parse_json(self):
        if self.headers.get('Content-Type','').split(';')[0].strip().lower()!='application/json':
            raise ValueError('Yêu cầu application/json.')
        try: n=int(self.headers.get('Content-Length') or '0')
        except ValueError: raise ValueError('Content-Length không hợp lệ.')
        if n<2 or n>MAX_BYTES: raise ValueError('Dữ liệu không hợp lệ hoặc quá lớn.')
        try: x=json.loads(self.rfile.read(n).decode('utf-8'))
        except (ValueError,UnicodeDecodeError): raise ValueError('JSON không hợp lệ.')
        if not isinstance(x,dict): raise ValueError('Cần dữ liệu dạng đối tượng JSON.')
        return x
    def authorized(self, write=False, admin=False):
        # Mọi người xem; chỉ cho sửa nếu cơ quan chủ động bật quyền ghi không đăng nhập.
        if write:
            if not ANONYMOUS_WRITE:
                raise ApiError(403,'Website đang ở chế độ chỉ xem. Cán bộ quản trị máy chủ cần bật quyền chỉnh sửa.')
            origin=self.headers.get('Origin')
            if origin:
                parts=urlsplit(origin)
                if parts.netloc.lower()!=self.headers.get('Host','').lower() or parts.scheme not in ('http','https'):
                    raise ApiError(403,'Yêu cầu chỉnh sửa từ trang web khác bị chặn.')
            now=int(time.time())
            ip=self.client_address[0]
            key=hashlib.sha256(ip.encode()).hexdigest()
            with connect() as db:
                r=db.execute('SELECT hits,window_start FROM anonymous_limits WHERE key_hash=?',(key,)).fetchone()
                if r and now-int(r['window_start'])<60:
                    if int(r['hits'])>=MAX_EDIT_PER_MINUTE:
                        raise ApiError(429,'Đã vượt giới hạn cập nhật/phút. Vui lòng thử lại sau.')
                    db.execute('UPDATE anonymous_limits SET hits=? WHERE key_hash=?',(int(r['hits'])+1,key))
                else:
                    db.execute("INSERT INTO anonymous_limits(key_hash,hits,window_start) VALUES(?,?,?) ON CONFLICT(key_hash) DO UPDATE SET hits=excluded.hits,window_start=excluded.window_start",(key,1,now))
        with connect() as db:
            anon=db.execute("SELECT id FROM users WHERE username='tramy_khong_dang_nhap'").fetchone()
        return {'id':anon['id'],'username':'khong-dang-nhap',
                'display_name':'Truy cập không đăng nhập','department':'',
                'role':'admin' if ANONYMOUS_WRITE else 'viewer','csrf':''}
    def route(self, method):
        path=urlsplit(self.path).path
        if path in ('/admin','/account','/api/login','/api/logout','/api/users','/api/change-password'):
            raise ApiError(404,'Phiên bản này không có tài khoản đăng nhập.')
        if method=='GET':
            if path=='/healthz':
                with connect() as db: db.execute('SELECT 1').fetchone()
                return self.json({'ok':True,'database':'connected'})
            if path in ('/','/index.html'):
                return self.send_bytes(200,(ROOT/'index.html').read_bytes(),'text/html; charset=utf-8')
            if path=='/admin':
                self.authorized(admin=True)
                return self.send_bytes(200,(ROOT/'admin.html').read_bytes(),'text/html; charset=utf-8')
            if path=='/account':
                self.authorized()
                return self.send_bytes(200,(ROOT/'account.html').read_bytes(),'text/html; charset=utf-8')
            if path=='/api/me':
                u=self.authorized()
                return self.json({k:u[k] for k in ('id','username','display_name','department','role','csrf')})
            if path=='/api/departments':
                self.authorized();return self.json({'departments':DEPARTMENTS})
            if path=='/api/data':
                self.authorized()
                with connect() as db:
                    rows=db.execute('SELECT dataset,content,department,revision,updated_at FROM records ORDER BY dataset,id').fetchall()
                result={'open':[],'shared':[],'staff':json.loads((ROOT/'seed.json').read_text(encoding='utf-8')).get('staff',[])}
                for row in rows:
                    r=json.loads(row['content']);r['department']=row['department'];r['revision']=int(row['revision']);r['updated_at']=row['updated_at'];result[row['dataset']].append(r)
                result['shared'].sort(key=lambda r:(int(r['stt']),int(re.sub(r'\D','',r['id']) or '999999')))
                return self.json(result)
            if path=='/api/users':
                self.authorized(admin=True)
                with connect() as db:
                    rows=db.execute('SELECT id,username,display_name,department,role,active,created_at FROM users ORDER BY role,department,display_name').fetchall()
                return self.json({'users':[dict(x) for x in rows]})
            if path=='/api/history':
                self.authorized(admin=True)
                with connect() as db:
                    rows=db.execute('''SELECT h.action,h.dataset,h.record_id,h.changed_at,u.display_name
                         FROM history h JOIN users u ON h.user_id=u.id ORDER BY h.id DESC LIMIT 200''').fetchall()
                return self.json({'history':[dict(x) for x in rows]})
            if path=='/api/backup':
                self.authorized(admin=True)
                with connect() as db:
                    rows=db.execute('SELECT dataset, content FROM records ORDER BY dataset,id').fetchall()
                data={'version':3,'exported_at':utcnow(),'open':[],'shared':[]}
                for row in rows: data[row['dataset']].append(json.loads(row['content']))
                return self.send_bytes(200,json.dumps(data,ensure_ascii=False,indent=2).encode('utf-8'),
                    'application/json; charset=utf-8',extra={'Content-Disposition':'attachment; filename="TraMy_sao_luu.json"'})
            raise ApiError(404,'Đường dẫn không tồn tại.')
        # Không có phiên đăng nhập hoặc đăng xuất trong bản này.
        if method=='POST' and path=='/api/record':
            user=self.authorized(write=True,admin=True)
            return self.save_record('POST',user)
        if method=='PATCH' and path=='/api/record':
            user=self.authorized(write=True)
            return self.save_record('PATCH',user)
        raise ApiError(404,'Đường dẫn không tồn tại.')
    def save_record(self, method, user):
        x=self.parse_json()
        dataset=x.get('dataset');incoming=x.get('record')
        obj=validate_record(dataset,incoming)
        try: incoming_rev=int(incoming.get('revision',0))
        except (ValueError,TypeError): incoming_rev=0
        with connect() as db:
            existing=db.execute('SELECT content,department,revision FROM records WHERE dataset=? AND id=?',(dataset,obj['id'])).fetchone()
            if method=='POST':
                if existing:raise ApiError(409,'Mã dòng đã tồn tại.')
                dept=normalize_dept(obj.get('unit','') if dataset=='open' else obj.get('position',''))
                if dept not in DEPARTMENTS:raise ValueError('Đơn vị quản lý chưa đúng. Hãy nhập đơn vị cụ thể trước khi thêm dòng.')
                db.execute('''INSERT INTO records(dataset,id,department,content,updated_at)
                    VALUES(?,?,?,?,?)''',(dataset,obj['id'],dept,json.dumps(obj,ensure_ascii=False),utcnow()))
                old=None; action='Thêm dòng';revision=1
            else:
                if not existing:raise ApiError(404,'Dòng này không còn tồn tại.')
                if int(existing['revision'])!=incoming_rev:
                    raise ApiError(409,'Dòng này vừa được người khác cập nhật. Hãy tải lại danh sách trước khi sửa.')
                old=json.loads(existing['content']);dept=existing['department']
                if user['role']!='admin':
                    if user['department']!=dept:raise ApiError(403,'Chỉ được sửa danh mục do đơn vị mình phụ trách.')
                    editable = ('assignee','email','uploaded','note') if dataset=='open' else ('assignee','email','entry_status','note','position')
                    for key,val in obj.items():
                        if key not in editable and val != old.get(key):
                            raise ApiError(403,'Cán bộ không được thay đổi tên danh mục, mã hoặc đơn vị chủ trì.')
                    if dataset=='shared' and normalize_dept(obj['position'])!=dept:
                        raise ApiError(403,'Không được chuyển phân hệ sang đơn vị khác.')
                else:
                    proposed=normalize_dept(obj.get('unit','') if dataset=='open' else obj.get('position',''))
                    # Chuyển đơn vị chỉ khi có tên hợp lệ. Giữ nguyên đơn vị quản lý nếu chức vụ là mô tả tự do.
                    if proposed in DEPARTMENTS: dept=proposed
                revision=incoming_rev+1; action=('Xóa phân công' if old.get('assignee') and not obj.get('assignee') and not obj.get('email') else 'Chỉnh sửa')
                cur=db.execute('''UPDATE records SET content=?,department=?,revision=?,updated_by=?,updated_at=?
                    WHERE dataset=? AND id=? AND revision=?''',
                    (json.dumps(obj,ensure_ascii=False),dept,revision,user['id'],utcnow(),dataset,obj['id'],incoming_rev))
                if cur.rowcount != 1:raise ApiError(409,'Dữ liệu đã thay đổi. Hãy tải lại trang.')
            db.execute('''INSERT INTO history(user_id,action,dataset,record_id,old_content,new_content,changed_at)
                 VALUES(?,?,?,?,?,?,?)''',(user['id'], action, dataset,obj['id'],
                    json.dumps(old,ensure_ascii=False) if old else None,json.dumps(obj,ensure_ascii=False),utcnow()))
        return self.json({'ok':True,'revision':revision})
    def do_GET(self):self.handle_req('GET')
    def do_POST(self):self.handle_req('POST')
    def do_PATCH(self):self.handle_req('PATCH')
    def handle_req(self,method):
        try:
            self.route(method)
        except ApiError as e:
            self.fail(e.message,e.status)
        except (ValueError,KeyError) as e:
            self.fail(str(e),400)
        except Exception:
            logging.exception('Lỗi xử lý yêu cầu %s %s',method,urlsplit(self.path).path)
            self.fail('Lỗi máy chủ. Vui lòng liên hệ quản trị viên.',500)


class ApiError(Exception):
    def __init__(self,status,message):
        self.status=status;self.message=message


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='cmd',required=True)
    cmd=sub.add_parser('serve');cmd.add_argument('--host',default='0.0.0.0');cmd.add_argument('--port',type=int,default=int(os.environ.get('PORT',8080)))
    cmd=sub.add_parser('init-db')
    args=parser.parse_args()
    if args.cmd=='init-db':setup();print('Đã kiểm tra cấu trúc CSDL.');return
    setup()
    server=ThreadingHTTPServer((args.host,args.port),AppHandler)
    server.daemon_threads=True
    logging.info('Web UBND xã Trà My đang chạy trên cổng %s, DB=%s',args.port,'PostgreSQL' if DB_URL else 'SQLite (local dev only)')
    try:server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:pass
    finally:server.server_close()

if __name__=='__main__':
    try:main()
    except (ValueError,sqlite3.IntegrityError) as exc:
        print('LỖI:',exc,file=sys.stderr);sys.exit(1)
